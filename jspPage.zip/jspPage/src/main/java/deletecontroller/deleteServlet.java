package deletecontroller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import integration.SaveService;
import model.Employee;

/**
 * Servlet implementation class deleteServlet
 */
@WebServlet("/deleteServlet")
public class deleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int empid = Integer.valueOf(request.getParameter("id"));
		System.out.println(empid);
		SaveService ss = new SaveService();
		boolean flag = ss.empdelete(empid);
		if(flag) {
			List<Employee> list = ss.emplist();
			request.setAttribute("emplist", list);
			RequestDispatcher rd = request.getRequestDispatcher("successPage.jsp");
			rd.forward(request, response);
		} else {
			List<Employee> list = ss.emplist();
			request.setAttribute("msg", "Employee can not be deleted due to some issue please try again");
			request.setAttribute("emplist", list);
			RequestDispatcher rd = request.getRequestDispatcher("successPage.jsp");
			rd.forward(request, response);
		}
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
