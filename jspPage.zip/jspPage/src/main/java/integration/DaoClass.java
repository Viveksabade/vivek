package integration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DaoClass {

	public String checkUserInDB(String userId) {
     
		String pass = "";
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root","Vivek@2605");		
		Statement stmt = con.createStatement();	
		ResultSet rs = stmt.executeQuery("select emp_pass from empdata where emp_Name='"+userId+"'");
		while(rs.next()) {
			pass = rs.getString("emp_pass");
		}
        } 
        catch(Exception e) {
        	e.printStackTrace();
        }
		return pass;
	}
}
