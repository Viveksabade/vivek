package integration;

public class Servicelogic {

	public boolean checkUserCredentials(String userId , String pass) {
		
		System.out.println("service class called "+userId+" "+pass);
		DaoClass daoClass = new DaoClass();
		String passfromDb = daoClass.checkUserInDB(userId);
		
		if(pass.equals(passfromDb)) {
			return true;
		}
		return false;
	}
}
