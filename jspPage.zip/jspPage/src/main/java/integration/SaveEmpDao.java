package integration;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.Employee;

public class SaveEmpDao {

	public boolean SaveEmpToDB(Employee emp) {

		boolean flag = false;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root","Vivek@2605");
			PreparedStatement ps = con.prepareStatement("insert into empdata (emp_Name,emp_Address,emp_Phone,emp_pass,emp_Email,emp_country,emp_gender) values(?,?,?,?,?,?,?)");
			ps.setString(1, emp.getEmpName());
			ps.setString(2, emp.getEmpCity());
			ps.setLong(3, emp.getEmpPhone());
			ps.setString(4, emp.getEmpPass());
			ps.setString(5, emp.getEmpEmail());
			ps.setString(6, emp.getEmpCountry());
			ps.setString(7, emp.getEmpGender());

			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			return flag;
		}
		
		return true;
	}

	public List<Employee> AllemplistfromDB() {

		List<Employee> employee = new ArrayList<>();
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root","Vivek@2605");
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from empdata");
		while(rs.next()) {
			Employee emp = new Employee();
			emp.setId(rs.getInt(1));
			emp.setEmpName(rs.getString(2));
			emp.setEmpCity(rs.getString(3));
			emp.setEmpPhone(rs.getLong(4));
			emp.setEmpPass(rs.getString(5));
			emp.setEmpEmail(rs.getString(6));
			emp.setEmpCountry(rs.getString(7));
			emp.setEmpGender(rs.getString(8));
			employee.add(emp);
		}
		} 
		catch(Exception e) {
			e.printStackTrace();
		}	
		return employee;
	}
	public boolean deleteEmp(Integer empid) {

		boolean flag = false;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root","Vivek@2605");
		Statement stmt = con.createStatement();
		int i = stmt.executeUpdate("delete from empdata where emp_Id="+empid);
		if(i>0) {
			flag = true;
		}
		}
		 catch(Exception e) {
			 e.printStackTrace();
		 }
		
		
		return flag;
	}
	

}
