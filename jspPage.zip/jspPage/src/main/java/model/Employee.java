package model;

public class Employee {
	private int id;
	private String empName;
	private String empPass;
	private String empCity;
	private Long empPhone;
	private String empEmail;
	private String empCountry;
	private String empGender;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpPass() {
		return empPass;
	}
	public void setEmpPass(String empPass) {
		this.empPass = empPass;
	}
	public String getEmpCity() {
		return empCity;
	}
	public void setEmpCity(String empCity) {
		this.empCity = empCity;
	}
	public Long getEmpPhone() {
		return empPhone;
	}
	public void setEmpPhone(Long empPhone) {
		this.empPhone = empPhone;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getEmpCountry() {
		return empCountry;
	}
	public void setEmpCountry(String empCountry) {
		this.empCountry = empCountry;
	}
	@Override
	public String toString() {
		return "Employee [Id=" + id + ", empName=" + empName + ", empPass=" + empPass + ", empCity=" + empCity
				+ ", empPhone=" + empPhone + ", empEmail=" + empEmail + ", empCountry=" + empCountry + ", empGender="
				+ empGender + "]";
	}
	
	
	

}
