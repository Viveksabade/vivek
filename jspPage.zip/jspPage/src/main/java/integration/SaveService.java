package integration;

import java.util.List;

import model.Employee;

public class SaveService {

	public boolean SaveEmpData(Employee emp) {

		SaveEmpDao sed = new SaveEmpDao();
		boolean flag = sed.SaveEmpToDB(emp);
				
			
		return flag;
		
	}

	public List<Employee> emplist() {

		SaveEmpDao sed = new SaveEmpDao();
		return sed.AllemplistfromDB();
		
	}

	public boolean empdelete(Integer empid) {

		SaveEmpDao sed = new SaveEmpDao();
		return sed.deleteEmp(empid);
		
	}
	
	

}
